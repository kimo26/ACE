__version__ = "0.0.1"
__author__ = "Karim Galal and Walid Chat"
__credits__ = "Analytics Club ETHZ"


